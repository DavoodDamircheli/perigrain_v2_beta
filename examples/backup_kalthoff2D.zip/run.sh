#!/bin/bash
path="`dirname \"$0\"`"

hpc="no"
#hpc="yes"

non_hpc_cores=2

# input from command line arg
#shape=$1
#theta=$2
#P_meshsize=$3

delta_frac=$1
echo "delta_frac = $delta_frac"

#resume="yes"
resume="no"

gen_setup="yes"
#gen_setup="no"

dirname="kalthoff-simpler"

if [ "$hpc" = "yes" ]
then
    data_output_loc="/work/$USER/peri-wheel-output/$dirname"
else
    data_output_loc="examples_output/$dirname"
fi

#plot=""
plot="--plot"

echo "#####################################################"

# paths
dir="$data_output_loc/delta_frac_$1_$2_$3_${finermsz}"
config=$dir/main.conf
sfile=$dir/setup.h5
logfile=$dir/output.log

mkdir -p $dir
echo "logfile: $logfile"
#clear logfile
echo '' > $logfile

# copy config file
cp $path/base.conf $config
cp $path/setup.py $dir/

if [ "$gen_setup" = "yes" ]
then
    echo "Generating experiment setup"
    ## generate experiment setup
    python3 $path/setup.py $plot --setup_file $sfile  --delta_frac $delta_frac>> $logfile
    cp setup.png $dir/
fi

# run code
echo 'running'

if [ "$hpc" = "yes" ]
then
    echo 'On hpc'
    export NPROCS=`wc -l $PBS_NODEFILE |gawk '//{print $1}'`
    echo "NPROCS=" 
    echo $NPROCS
    mpirun -machinefile $PBS_NODEFILE -np $NPROCS bin/simulate2d -c $config -o $dir -i $sfile  >> $logfile
else
    echo "On non-hpc with ${non_hpc_cores} cores"
    mpirun -n ${non_hpc_cores} bin/simulate2d -c $config -o $dir -i $sfile  >> $logfile
fi

echo 'Generating plots'
python3 plot_timestep.py --data_dir $dir --img_dir $dir --setup_file $sfile --dotsize 4
sxiv $dir/*.png

## generate video
#echo 'Generating video'
#./gen_vid.sh $dir

# generate attribute plot
#$path/plot_attrib.sh "$dir" "$path"
