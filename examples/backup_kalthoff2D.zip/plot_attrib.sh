#path="`dirname \"$0\"`"
ind=3
#dir="examples_output/9part_test/____/"
dir=$1
#path="examples/paper-9-part_test"
path=$2
#quantity=fd_x

#for quantity in fd_x fd_y contact_force_x contact_force_y
for quantity in fd_x fd_y
do
    python3 $path/attrib.py --all_dir $dir --quantity $quantity --wheel_ind $ind
done

sxiv $dir/plot_$quantity.png
