import numpy as np
# import time
from random import seed
from random import random

import sys, os
sys.path.append(os.getcwd())

import shape_dict, material_dict
# from genmesh import genmesh
from exp_dict import ShapeList, Wall, Contact, Experiment, plot_setup, GridDist, Particle
from genmesh import genmesh
from itertools import combinations
# from pathos.multiprocessing import ProcessingPool as Pool
from pathos.multiprocessing import ProcessPool as Pool
# from pathos.pools import ParallelPool as Pool
# from multiprocessing import Pool
import time

from mpi4py import MPI
comm = MPI.COMM_WORLD
size = comm.Get_size()
rank = comm.Get_rank()
print('rank', rank, flush=True)

from arrangements import get_incenter_mesh_loc

from shape_params import Param
import argparse
# Instantiate the parser
parser = argparse.ArgumentParser(description='Optional app description')
# Optional argument
# parser.add_argument('--P_meshsize', type=float, help='avg grain size', default=80e-3)
# parser.add_argument('--shape_param_1', type=float, help='parameter for grain geometry', default=0.4)
parser.add_argument('--setup_file', type=str, help='output setup directory', default='data/hdf5/all.h5')
parser.add_argument('--delta_frac', type=float, help='fraction of radius to be equal to delta', default=4)
# parser.add_argument('--read_arrangement', action='store_true', help='read from arrangement or not')
# parser.add_argument('--arrangement_file', type=str, help='read particle arrangement from file', default='output/csv/arrangement.csv')
# parser.add_argument('--wheel_rad', type=str, help='output filename containing wheel radius', default='output/wheel_rad')
parser.add_argument('--plot', action='store_true', help='whether plot or not')
# finish parsing
args = parser.parse_args()

print('plot', args.plot)
print('saving experiment setup to', args.setup_file)

l = 200e-3
s = 100e-3
dist = 50e-3
a = 1.5e-3
# v_val = -32
v_val = -32

# meshsize = l/320
#meshsize = l/100
meshsize = l/120
#meshsize = l/80
#meshsize = l/50
delta = meshsize * args.delta_frac
# contact_radius = delta/1.5
contact_radius = delta/2

clamp = True
# clamp = False

prescribe = True
# prescribe = False

Gnot_scale = 1
rho_scale = 1
## to match the masses of both particles, need to scale up the density of the impactor
## volume of sheet V_A = (100e-3 * 200e-3 * 10e-3)
## mass of sheet m_A = (100e-3 * 200e-3 * 10e-3) * 8000 = 1.6 kg
## volume of impactor V_B = (pi * 25e-3^2 * 100e-3)
## mass of the impactor m_B = V_B * 8000 = 1.57 kg
## The mass of the impactor and the sheet are almost the same, 1.57 kg vs 1.6 kg
## So, to deliver the same momentum, we scale the density by the area scaling so that the mass are the same
impact_rho_scaling = 4


# delta_to_rad_fac = args.delta_frac
# meshsize_to_delta_fac = 3
# cont_to_rad_fac = 5


g_val = 0


# boundary of container
L = (s/2 + 2*dist + 2*contact_radius)
hh = L


bulk_wall_left   = -L
bulk_wall_right  = L
bulk_wall_top    = hh
bulk_wall_bottom = -hh

wall_left   = -L - contact_radius/2
wall_right  = L + contact_radius/2
wall_top    = hh + contact_radius/2
wall_bottom = -hh - contact_radius/2

# wall_bottom = -5e-3
wall = Wall(1, wall_left, wall_right, wall_top, wall_bottom)


# Create a list of shapes
SL = ShapeList()

# append each shape with own scaling
# steps = 30
# shape=shape_dict.small_disk(steps=steps, scaling=circ_rad)
shape=shape_dict.kalthoff(l=l, s=s, dist=dist, a=a)
material=material_dict.kalthoff(delta)
material.print()
SL.append(shape=shape, count=1, meshsize=meshsize, material=material)

mesh = genmesh(P_bdry=shape.P, pygmsh_geom=shape.pygmsh_geom, meshsize=meshsize, dimension=2)
# mesh.plot(plot_node_text=False)

main_start_sh = time.time()

def test_single_bond(ij_pair):
# def test_single_bond(ij_pair, pos):
# def test_single_bond(mesh, ij_pair):
    pos = mesh.pos

    # print('ij', ij_pair, end='\n', flush=True)
    i = ij_pair[0]
    j = ij_pair[1]
    # if i==1 and j==2:
        # print('\n started after', time.time() - main_start_sh)
    p_i = pos[i]
    p_j = pos[j]
    d = np.sqrt(np.sum(np.square(p_j - p_i))) #norm
    if (d <= material.delta):
            return [i,j]
    else:
        # return [0,0]
        return None

iter_all_ij = combinations(range(len(mesh.pos)),2)
all_ij = [ij for ij in iter_all_ij]
n = len(mesh.pos)
nc2 = int(n*(n-1)/2)

# empty = [[0,0]]*nc2
#print(empty)
#######################################################################
# MPI

this_list = []
for p in range(rank, nc2, size):    # mpi
    ij = all_ij[p]
    out = test_single_bond(ij)
    if out:
        this_list.append(out)


result = comm.gather(this_list, root=0)


if rank == 0:
    joined = [j for i in result for j in i]
    print(len(joined))
    print('\nTime taken', time.time() - main_start_sh)



# print("parallel pool now")
# a_pool = Pool()
# start_sh = time.time()
# all_bonds = a_pool.map(test_single_bond, all_ij) 
# # all_bonds = a_pool.map(test_single_bond, all_ij, [mesh.pos]*nc2)
# print('\n time taken', time.time() - start_sh)
# # print(all_bonds)
# out = np.array([i for i in all_bonds if i is not None])
# print('total number of bonds', len(out))

# PP = Particle(mesh=mesh, shape=shape, material=material, nbdarr_in_parallel=True)


# if not prescribe:
    # SL.append(shape=shape_dict.plank(l=dist/2, s=dist), count=1, meshsize=meshsize, material=material_dict.peridem_deformable(delta, Gnot_scale=Gnot_scale, rho_scale=impact_rho_scaling))

# # generate the mesh for each shape
# particles = SL.generate_mesh(dimension = 2, contact_radius = contact_radius, plot_mesh=False, plot_shape=False, shapes_in_parallel=False)

# sheet = particles[0][0]

# if clamp:
    # for i in range(len(sheet.pos)):
        # if (np.abs(sheet.pos[i,1] - (s/2)) < 1e-12):
            # if (np.abs(sheet.pos[i,0] - (0)) > dist/2+a):
                # sheet.clamped_nodes.append(i)
    # print(sheet.clamped_nodes)

# if prescribe:
    # #specify boundary velocity
    # for i in range(len(sheet.pos)):
        # if (np.abs(sheet.pos[i,1] - (s/2)) < 1e-12):
            # if (np.abs(sheet.pos[i,0] - (0)) < delta):
                # sheet.vel[i] += [0, v_val]
# else:
    # part = particles[1][0]
    # part.shift([0, s/2+dist+contact_radius*1.1])
    # part.vel += [0, v_val]
    # part.breakable = 0


# # contact properties
# normal_stiffness = 18 * material_dict.peridem(delta).bulk_modulus /( np.pi * np.power(delta,4));
# # normal_stiffness = material.cnot / contact_radius
# damping_ratio = 0.8
# friction_coefficient = 0.8
# contact  = Contact(contact_radius, normal_stiffness, damping_ratio, friction_coefficient)

# if args.plot:
    # print('Plotting')
    # plot_setup(particles, dotsize=1, contact_radius=contact_radius, show_plot=False, wall=wall, show_particle_index=True)

# # return Experiment(particles, wall, contact)
# exp =  Experiment(particles, wall, contact)

# #######################################################################

# # save the data
# print('saving experiment setup to', args.setup_file)
# exp.save(args.setup_file)
