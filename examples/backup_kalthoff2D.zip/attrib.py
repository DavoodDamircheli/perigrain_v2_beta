import sys, os
sys.path.append(os.getcwd())
import numpy as np
import h5py
import re
# from multiprocessing import Pool
from pathos.multiprocessing import ProcessingPool as Pool
import time

from scipy.signal import savgol_filter
# yhat = savgol_filter(y, 51, 3) # window size 51, polynomial order 3
from scipy.stats import linregress

import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
from matplotlib.collections import LineCollection

import argparse
# Instantiate the parser
parser = argparse.ArgumentParser(description='Optional app description')

# Optional argument
parser.add_argument('--data_dir', type=str, help='input data directory', default='output/hdf5/')
parser.add_argument('--setup_file', type=str, help='output setup file', default='data/hdf5/all.h5')
parser.add_argument('--all_dir', type=str, help='directory where all files are located')
parser.add_argument('--img_dir', type=str, help='output image directory', default='output/img/')
parser.add_argument('--img_filename', type=str, help='output image file name', default='velocity')

parser.add_argument('--fc', type=int, help='first counter')
parser.add_argument('--lc', type=int, help='last counter')

parser.add_argument('--quantity', type=str, help='quantity to plot', default='vel_angular')


parser.add_argument('--wheel_ind', type=int, help='index of wheel particle', default=0)
parser.add_argument('--nbr_ind', type=int, help='index of neighboring particle with which particle[wheel_ind] is in contact', default=4)

parser.add_argument('--plot', action='store_true', help='whether plot or not')
parser.add_argument('--avg', action='store_true', help='average out the data')
parser.add_argument('--avg_window', type=int, help='window size to average over', default=2)
parser.add_argument('--serial', action='store_true', help='read timesteps in serial')

parser.add_argument('--regression_fc', type=int, help='first timestep for regression', default=1)

# finish parsing
args = parser.parse_args()


data_dir = args.data_dir
img_dir = args.img_dir
setup_filename = args.setup_file

if args.all_dir:
    data_dir       = args.all_dir
    img_dir        = args.all_dir
    setup_filename = args.all_dir+'/setup.h5'

# plot info
plotinfo_file = data_dir+'/plotinfo.h5'
p = h5py.File(plotinfo_file, "r")
fc = int(p['f_l_counter'][0])
lc = int(p['f_l_counter'][1])
dt = float(p['dt'][0])
modulo = int(p['modulo'][0])

if args.fc:
    fc = args.fc
if args.lc:
    lc = args.lc

def movingaverage(array, window_size):
    window = np.ones(int(window_size))/float(window_size)
    return np.convolve(array, window, 'same')

def total_neighbors(conn, N):
    """Compute the total number of neighbors from connectivity data
    :conn: connectivity matrix, mx2, m=total intact bonds
    :N: total number of nodes
    :returns: TODO
    """
    deg = np.zeros(N)
    for i in range(len(conn)):
        deg[conn[i][0]] += 1
        deg[conn[i][1]] += 1
    return deg

f = h5py.File(setup_filename, "r")
contact_radius = np.array(f['pairwise/contact_radius']).astype(float)[0][0]
print('contact_radius', contact_radius)

class RefSetup(object):
    """Reference setup"""
    def __init__(self, setup_filename):
        self.setup_filename = setup_filename
        self.orig_f = h5py.File(self.setup_filename, "r")

    def get_volume(self, index):
        name = ('P_%05d' % index)
        vol = np.array(self.orig_f[name+'/Vol'])
        return np.sum(vol, axis=0)[0]
    
    def get_moment_of_inertia(self, index, include_density=False):
        """ Return the moment of inertia, divided the rho
        i.e. \int r^2 dA
        """
        name = ('P_%05d' % index)
        vol = np.array(self.orig_f[name+'/Vol'])
        pos = np.array(self.orig_f[name+'/Pos'])
        centroid = np.mean(pos, axis=0)
        r_vec = pos - centroid
        r = np.sqrt( np.sum(r_vec**2, axis=1) )
        # out = np.sum((r**2) * vol)
        out = np.sum((r**2) * np.squeeze(np.asarray(vol)))
        if include_density:
            rho = np.array(self.orig_f[name+'/rho'])
            out *= rho
        return out



def vel(t):
    print(t)
    tc_ind = ('%05d' % t)
    filename = data_dir+'/tc_'+tc_ind+'.h5'
    f = h5py.File(filename, "r")
    orig_f = h5py.File(setup_filename, "r")

    name = ('P_%05d' % args.wheel_ind)
    currpos = np.array(f[name+'/CurrPos'])
    centroid = np.mean(currpos, axis=0)
    vel = np.array(f[name+'/vel'])
    vel_mean = np.mean(vel, axis=0)

    fd = np.array(f[name+'/force'])
    fd_tot = np.sum(fd, axis=0)

    # angular velocity
    w_tot = 0
    # radius of the body
    R = 0
    for j in range(len(currpos)):
        r_vec = (currpos[j] - centroid)
        r = np.sqrt( np.sum(r_vec**2) )
        R = max(R, r)
        r_dir = r_vec / r
        # velocity on the frame of reference at the centroid
        v = vel[j] - vel_mean
        # Debug: not subtracting the mean
        # v = vel[j]
        v_r = np.dot(v, r_dir) * r_dir
        v_t = v - v_r
        v_t_norm = np.sqrt(np.sum(v_t**2))
        w_this = v_t_norm/r

        w_tot += w_this
    w_mean = w_tot/len(currpos)
    # print(w_mean)

    if args.quantity == 'vel_angular':
        return w_mean
    elif args.quantity == 'vel_x':
        return vel_mean[0]
    elif args.quantity == 'vel_y':
        return vel_mean[1]
    elif args.quantity == 'slip':
        numerator = R * w_mean - vel_mean[0]
        if numerator > 0:
            return numerator/ (R*w_mean)
        elif numerator < 0:
            return numerator/ vel_mean[0]
        else:
            return 0
    elif args.quantity == 'fd_x':
        return fd_tot[0]
    elif args.quantity == 'fd_y':
        return fd_tot[1]
    # elif args.quantity == 'contact_force':
    elif (args.quantity == 'contact_force_x') or (args.quantity == 'contact_force_y') or (args.quantity == 'contact_force_norm') or (args.quantity == 'contact_force_vec'):
        # contact force on all nodes from particle nbd_ind
        # cnode_list = set()
        print('Contact force on', args.wheel_ind, 'due to', args.nbr_ind)
        cnode_list = []
        nbr_name = ('P_%05d' % args.nbr_ind)
        nbr_currpos = np.array(f[nbr_name+'/CurrPos'])
        for node in range(len(currpos)):
            for i in range(len(nbr_currpos)):
                dist = np.sqrt(np.sum((nbr_currpos[i] - currpos[node])**2))
                if dist <= contact_radius:
                    cnode_list.append(node)
                    break
        do_plot  = 0
        if do_plot:
            # plot contact nodes
            print('contact nodes', len(cnode_list))
            print('total nodes', len(currpos))
            plt.scatter(currpos[:,0], currpos[:,1], color='blue')
            plt.scatter(currpos[cnode_list,0], currpos[cnode_list,1], color='red')
            plt.axis('scaled')
            # plt.show()
            # plt.close()

            save_filename = img_dir+'/contact_'+tc_ind+'.png'
            print('saving to', save_filename)
            plt.savefig(save_filename, dpi=300, bbox_inches='tight')
            plt.close()
        # sum all the forces
        cforce = np.sum(fd[cnode_list],axis=0)
        print(cforce)


        # output x-component
        if (args.quantity == 'contact_force_x'):
            return cforce[0]
        elif (args.quantity == 'contact_force_y'):
            return cforce[1]
        elif (args.quantity == 'contact_force_norm'):
            return np.sqrt(np.sum(cforce**2))
        elif (args.quantity == 'contact_force_vec'):
            return cforce

tt = range(fc, lc+1)

t_vols = []
if args.serial:
    # serial j
    for t in tt:
        t_vols.append(vel(t))
else:
    ## parallel
    a_pool = Pool()
    t_vols = a_pool.map(vel, tt)
    a_pool.close()

## quantity to plot
qq = [
        ## x-velocity
        # v[0]
        ## angular velocity
        v 
        for v in t_vols]

if args.avg:
    qq = movingaverage(qq, args.avg_window)


# actual time
time = np.array(tt) * dt * modulo
print(qq)
plt.plot(time, qq, label='numerical')

## slope
slope, intercept, r_value, p_value, std_err = linregress(time[args.regression_fc:], qq[args.regression_fc:])
# print(slope,intercept)
print('slope',slope)
regr = slope * time + intercept
plt.plot(time[1::2], regr[1::2], 'x', label='regression')

# slope2 = 149087.1691421817
# regr2 = slope2 * time + intercept
# plt.plot(time, regr2, 'x', label='theoretical')

plt.grid()
plt.title(args.quantity)
plt.legend()
out_png = img_dir+'/plot_'+str(args.quantity)+'.png'
print('Saving img to', out_png)
plt.savefig(out_png, dpi=300, bbox_inches='tight')

# ref = RefSetup(setup_filename)
# print('moment of inertia', ref.get_moment_of_inertia(0))
# print('total volume', ref.get_volume(0))


if args.plot:
    plt.show()
